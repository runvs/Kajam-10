var searchData=
[
  ['file_46',['File',['../namespacetson.html#a072f9f86eaa4189282ed315ddfde0094a0b27918290ff5323bea1e3b78a9cf04e',1,'tson']]],
  ['filename_47',['fileName',['../classtson_1_1WorldMapData.html#a40c06015eff3a327c1b46673261408d1',1,'tson::WorldMapData']]],
  ['filenotfound_48',['FileNotFound',['../namespacetson.html#a7e7be825d3bd60100bb41677df44168ba2767828026039e8ba7b38973cbb701f2',1,'tson']]],
  ['firstobj_49',['firstObj',['../classtson_1_1Layer.html#a1b635e2b5a9aec6921990b4946689475',1,'tson::Layer']]],
  ['flaggedtile_50',['FlaggedTile',['../classtson_1_1FlaggedTile.html',1,'tson::FlaggedTile'],['../classtson_1_1FlaggedTile.html#a47e374d15a87c7e8cde57923ee9ab66d',1,'tson::FlaggedTile::FlaggedTile()']]],
  ['flaggedtile_2ehpp_51',['FlaggedTile.hpp',['../FlaggedTile_8hpp.html',1,'']]],
  ['float_52',['Float',['../namespacetson.html#a072f9f86eaa4189282ed315ddfde0094a22ae0e2b89e5e3d477f988cc36d3272b',1,'tson']]],
  ['folder_53',['folder',['../classtson_1_1WorldMapData.html#acd173e8cc5f4ee4379306a38bd38a582',1,'tson::WorldMapData']]],
  ['folderpaths_54',['folderPaths',['../classtson_1_1ProjectData.html#ac6c9bf1185eb59e17d8b8c7b9212b992',1,'tson::ProjectData']]],
  ['folders_55',['folders',['../classtson_1_1ProjectData.html#a21567e1bc681563fafbc4fe481ad91d5',1,'tson::ProjectData']]],
  ['frame_56',['Frame',['../classtson_1_1Frame.html',1,'tson::Frame'],['../classtson_1_1Frame.html#ad9ca20e025d3370501a64a2f7ef0b5e0',1,'tson::Frame::Frame()=default'],['../classtson_1_1Frame.html#afa26f72c1cda0575d143f1c6381d4c10',1,'tson::Frame::Frame(int duration, int tileId)'],['../classtson_1_1Frame.html#a57364e4580faa6246c419b015e694c97',1,'tson::Frame::Frame(const nlohmann::json &amp;json)']]],
  ['frame_2ehpp_57',['Frame.hpp',['../Frame_8hpp.html',1,'']]]
];
