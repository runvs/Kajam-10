var searchData=
[
  ['id_169',['id',['../classtson_1_1FlaggedTile.html#a722fc130f36de3b97397263da36552f9',1,'tson::FlaggedTile']]],
  ['idecompressor_170',['IDecompressor',['../classtson_1_1IDecompressor.html',1,'tson']]],
  ['idecompressor_2ehpp_171',['IDecompressor.hpp',['../IDecompressor_8hpp.html',1,'']]],
  ['imagelayer_172',['ImageLayer',['../namespacetson.html#ac06ac2288d940483c17a83daf587780da4f1851a3abdf8696a00a4e22d5ec178c',1,'tson']]],
  ['initialize_173',['initialize',['../classtson_1_1TileObject.html#adeaeefb6ddd5c4551404b2311695edd6',1,'tson::TileObject']]],
  ['int_174',['Int',['../namespacetson.html#a072f9f86eaa4189282ed315ddfde0094a1686a6c336b71b36d77354cea19a8b52',1,'tson']]],
  ['isellipse_175',['isEllipse',['../classtson_1_1Object.html#ad4e021ff8d2eaa7c660d8b90db3ec005',1,'tson::Object']]],
  ['isinfinite_176',['isInfinite',['../classtson_1_1Map.html#aeb7fd31ac283a3e7156d2ff528215932',1,'tson::Map']]],
  ['ispoint_177',['isPoint',['../classtson_1_1Object.html#afda3ed8a906aef01e4b834ece6965e50',1,'tson::Object']]],
  ['isvisible_178',['isVisible',['../classtson_1_1Layer.html#a9f15627018a6cd843babcd177c910bce',1,'tson::Layer::isVisible()'],['../classtson_1_1Object.html#ab2c504d55d8ddadd40cef0ca3711d49d',1,'tson::Object::isVisible()']]]
];
