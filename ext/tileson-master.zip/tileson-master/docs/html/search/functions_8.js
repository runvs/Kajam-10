var searchData=
[
  ['initialize_503',['initialize',['../classtson_1_1TileObject.html#adeaeefb6ddd5c4551404b2311695edd6',1,'tson::TileObject']]],
  ['isellipse_504',['isEllipse',['../classtson_1_1Object.html#ad4e021ff8d2eaa7c660d8b90db3ec005',1,'tson::Object']]],
  ['isinfinite_505',['isInfinite',['../classtson_1_1Map.html#aeb7fd31ac283a3e7156d2ff528215932',1,'tson::Map']]],
  ['ispoint_506',['isPoint',['../classtson_1_1Object.html#afda3ed8a906aef01e4b834ece6965e50',1,'tson::Object']]],
  ['isvisible_507',['isVisible',['../classtson_1_1Layer.html#a9f15627018a6cd843babcd177c910bce',1,'tson::Layer::isVisible()'],['../classtson_1_1Object.html#ab2c504d55d8ddadd40cef0ca3711d49d',1,'tson::Object::isVisible()']]]
];
