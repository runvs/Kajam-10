var searchData=
[
  ['vector2_550',['Vector2',['../classtson_1_1Vector2.html#abc9453580237e6790341456459c294d4',1,'tson::Vector2::Vector2(T xPos, T yPos)'],['../classtson_1_1Vector2.html#a38e61ea4b374c0e044d7272a11dd554c',1,'tson::Vector2::Vector2()']]]
];
