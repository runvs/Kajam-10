var searchData=
[
  ['hasdflip_161',['hasDFlip',['../classtson_1_1WangTile.html#a90f90d24a6a3cf1108935da9d895c705',1,'tson::WangTile']]],
  ['hasflipflags_162',['hasFlipFlags',['../classtson_1_1Object.html#a22e5910e077d32be2076e425be7ced87',1,'tson::Object::hasFlipFlags()'],['../classtson_1_1Tile.html#a84ca313098600197ed89b3876f4a4720',1,'tson::Tile::hasFlipFlags()']]],
  ['hashflip_163',['hasHFlip',['../classtson_1_1WangTile.html#a48c4973ec700d342d91f9bb2abe23597',1,'tson::WangTile']]],
  ['hasproperty_164',['hasProperty',['../classtson_1_1PropertyCollection.html#a9460ec4fa2395e6f0e7324243b38028e',1,'tson::PropertyCollection']]],
  ['hasvflip_165',['hasVFlip',['../classtson_1_1WangTile.html#add4f356ec08dd3cc7c839c79b29391d6',1,'tson::WangTile']]],
  ['hasworldfile_166',['hasWorldFile',['../classtson_1_1ProjectFolder.html#ae813e2a28195bda9e38ea9250b6c3576',1,'tson::ProjectFolder']]],
  ['height_167',['height',['../classtson_1_1Rect.html#a06e642a98248c43b80ac04b05a1a5fc4',1,'tson::Rect']]],
  ['horizontally_168',['Horizontally',['../namespacetson.html#abcd37c33daaa7579bf76831bc470113da82d96265a801bd741cb308aea729e587',1,'tson']]]
];
