var searchData=
[
  ['add_376',['add',['../classtson_1_1DecompressorContainer.html#a5d13e3f29f043acc9f6622743d136cd9',1,'tson::DecompressorContainer::add()'],['../classtson_1_1PropertyCollection.html#a12f1839416855a8e16a23f67b5c98508',1,'tson::PropertyCollection::add(const tson::Property &amp;property)'],['../classtson_1_1PropertyCollection.html#a6c0da3e1ac66463263bc3331697ff5fb',1,'tson::PropertyCollection::add(const nlohmann::json &amp;json)'],['../classtson_1_1PropertyCollection.html#ae4b5dac635c868b424d756a27075ffe1',1,'tson::PropertyCollection::add(const std::string &amp;name, const std::any &amp;value, tson::Type type)']]],
  ['addtilesetandperformcalculations_377',['addTilesetAndPerformCalculations',['../classtson_1_1Tile.html#ad5e7e2693fc119ee253346ec8039b6e6',1,'tson::Tile']]],
  ['asfloat_378',['asFloat',['../classtson_1_1Color.html#a7829ed9dd232a30f8c9977aa63800d3b',1,'tson::Color']]],
  ['asint_379',['asInt',['../classtson_1_1Color.html#a23692d80c57432d1b241f0c94d413eea',1,'tson::Color']]],
  ['assigntilemap_380',['assignTileMap',['../classtson_1_1Layer.html#a1bfad85349d2f026201b7cad0419878b',1,'tson::Layer']]]
];
