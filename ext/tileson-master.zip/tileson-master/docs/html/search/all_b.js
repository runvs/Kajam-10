var searchData=
[
  ['name_196',['name',['../classtson_1_1Base64Decompressor.html#aa68ecadc13e74d724780b6eba200d657',1,'tson::Base64Decompressor::name()'],['../classtson_1_1IDecompressor.html#a1f98ddd8214fcf5ca516ffdd2c87f02e',1,'tson::IDecompressor::name()']]],
  ['none_197',['None',['../namespacetson.html#abcd37c33daaa7579bf76831bc470113da6adf97f83acf6453d4a6a4b1070f3754',1,'tson']]]
];
