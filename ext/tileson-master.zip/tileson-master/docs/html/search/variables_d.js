var searchData=
[
  ['text_582',['text',['../classtson_1_1Text.html#af3d6a5e6b34ce9a422b2ae9b968215ad',1,'tson::Text']]],
  ['tileid_583',['tileId',['../classtson_1_1FlaggedTile.html#a494b1a394d58de25cf65e4761adb7477',1,'tson::FlaggedTile']]]
];
