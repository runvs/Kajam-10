var searchData=
[
  ['color_561',['color',['../classtson_1_1Text.html#a3e7302050e4bcbdfdcbfb74fa861c0e6',1,'tson::Text']]],
  ['commands_562',['commands',['../classtson_1_1ProjectData.html#ab2674aaa5d323fe1bf96132df7b7efeb',1,'tson::ProjectData']]]
];
