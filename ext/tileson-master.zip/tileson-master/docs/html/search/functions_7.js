var searchData=
[
  ['hasdflip_497',['hasDFlip',['../classtson_1_1WangTile.html#a90f90d24a6a3cf1108935da9d895c705',1,'tson::WangTile']]],
  ['hasflipflags_498',['hasFlipFlags',['../classtson_1_1Object.html#a22e5910e077d32be2076e425be7ced87',1,'tson::Object::hasFlipFlags()'],['../classtson_1_1Tile.html#a84ca313098600197ed89b3876f4a4720',1,'tson::Tile::hasFlipFlags()']]],
  ['hashflip_499',['hasHFlip',['../classtson_1_1WangTile.html#a48c4973ec700d342d91f9bb2abe23597',1,'tson::WangTile']]],
  ['hasproperty_500',['hasProperty',['../classtson_1_1PropertyCollection.html#a9460ec4fa2395e6f0e7324243b38028e',1,'tson::PropertyCollection']]],
  ['hasvflip_501',['hasVFlip',['../classtson_1_1WangTile.html#add4f356ec08dd3cc7c839c79b29391d6',1,'tson::WangTile']]],
  ['hasworldfile_502',['hasWorldFile',['../classtson_1_1ProjectFolder.html#ae813e2a28195bda9e38ea9250b6c3576',1,'tson::ProjectFolder']]]
];
