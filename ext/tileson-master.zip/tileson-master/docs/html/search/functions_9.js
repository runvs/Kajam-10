var searchData=
[
  ['layer_508',['Layer',['../classtson_1_1Layer.html#ac744d2ba56eb9e2e11063db895c7318b',1,'tson::Layer::Layer()=default'],['../classtson_1_1Layer.html#a609a3673599840415869ab05cc473318',1,'tson::Layer::Layer(const nlohmann::json &amp;json, tson::Map *map)']]],
  ['loadmaps_509',['loadMaps',['../classtson_1_1World.html#a013ba94da8ae973705365456abee9dfa',1,'tson::World']]]
];
