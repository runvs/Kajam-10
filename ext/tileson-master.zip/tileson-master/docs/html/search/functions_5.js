var searchData=
[
  ['firstobj_394',['firstObj',['../classtson_1_1Layer.html#a1b635e2b5a9aec6921990b4946689475',1,'tson::Layer']]],
  ['flaggedtile_395',['FlaggedTile',['../classtson_1_1FlaggedTile.html#a47e374d15a87c7e8cde57923ee9ab66d',1,'tson::FlaggedTile']]],
  ['frame_396',['Frame',['../classtson_1_1Frame.html#ad9ca20e025d3370501a64a2f7ef0b5e0',1,'tson::Frame::Frame()=default'],['../classtson_1_1Frame.html#afa26f72c1cda0575d143f1c6381d4c10',1,'tson::Frame::Frame(int duration, int tileId)'],['../classtson_1_1Frame.html#a57364e4580faa6246c419b015e694c97',1,'tson::Frame::Frame(const nlohmann::json &amp;json)']]]
];
