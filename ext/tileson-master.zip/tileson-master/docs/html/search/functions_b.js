var searchData=
[
  ['name_513',['name',['../classtson_1_1Base64Decompressor.html#aa68ecadc13e74d724780b6eba200d657',1,'tson::Base64Decompressor::name()'],['../classtson_1_1IDecompressor.html#a1f98ddd8214fcf5ca516ffdd2c87f02e',1,'tson::IDecompressor::name()']]]
];
